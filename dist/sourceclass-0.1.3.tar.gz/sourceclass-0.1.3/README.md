# source-classes

Source classes package for the SAA project for the git, github, and jira data.

## Installation

You can install the `sourceclasses` package using pip. Use the following command:

```bash
pip install sourceclass==0.1
